//
//  CULocGroupValue.h
//  Cornell University Game Library (CUGL)
//
//  ...
//
//  CUGL MIT License:
//      This software is provided 'as-is', without any express or implied
//      warranty.  In no event will the authors be held liable for any damages
//      arising from the use of this software.
//
//      Permission is granted to anyone to use this software for any purpose,
//      including commercial applications, and to alter it and redistribute it
//      freely, subject to the following restrictions:
//
//      1. The origin of this software must not be misrepresented; you must not
//      claim that you wrote the original software. If you use this software
//      in a product, an acknowledgment in the product documentation would be
//      appreciated but is not required.
//
//      2. Altered source versions must be plainly marked as such, and must not
//      be misrepresented as being the original software.
//
//      3. This notice may not be removed or altered from any source
//      distribution.
//
//  Author: Pedro Pontes García
//  Version:
#ifndef __CU_LOC_GROUP_VALUE_H__
#define __CU_LOC_GROUP_VALUE_H__

#include <cugl/core/CUBase.h>
#include <cugl/core/assets/CUJsonValue.h>

// TO BE REMOVED
#include <cugl/core/util/CUDebug.h>

#include <unordered_map>

namespace cugl {

/**
 * This class represents a collection of localized string tables in JSON form.
 *
 * A locale group is a JSON object that maps language codes (e.g., "en", "es")
 * to flat key-value tables of localized strings. Each entry is a mapping from
 * a localization key (like "menu.start") to its translated string. For example:
 *
 *     {
 *         "en": {
 *             "menu.start": "Start Game",
 *             "menu.quit": "Quit"
 *         },
 *         "es": {
 *             "menu.start": "Comenzar",
 *             "menu.quit": "Salir"
 *         },
 *         "meta": {
 *             "current": "es",
 *             "supported": {
 *                 "en": "English",
 *                 "es": "Español"
 *             }
 *         }
 *     }
 *
 * This class provides access to the active locale (as specified by the "meta.current"
 * key) and allows lookup of localized strings by key. It also supports querying
 * the list of supported languages and switching the active locale at runtime.
 */
class LocaleGroup {
protected:
    std::shared_ptr<JsonValue> _json;

public:
    /**
     * Creates a null LocaleGroup.
     *
     * NEVER USE A CONSTRUCTOR WITH NEW. If you want to allocate an object on
     * the heap, use one of the static constructors instead.
     */
    LocaleGroup() {};

    /**
     * Deletes this LocaleGroup and all of its resources.
     *
     * If no other references own the descendants of this node, they will all
     * be recursively deleted as well.
     */
    ~LocaleGroup() {};

    /**
     * Initializes a new LocaleGroup to wrap the given JsonValue.
     *
     * This initializer simply wraps the provided JSON.
     *
     * @param json  A shared pointer to a JsonValue that defines this locale group.
     *
     * @return  true if the JsonValue is not a nullptr, false otherwise.
     */
    bool init(const std::shared_ptr<JsonValue>& json) {
        if (json == nullptr) {
            return false;
        }

        _json = json;
        return true;
    }

    /**
     * Returns a newly allocated LocaleGroup to wrap the given JsonValue.
     *
     * @param json  A shared pointer to a JsonValue that defines this locale group.
     *
     * @return a newly allocated LocaleGroup wrapping the provided JsonValue.
     */
    static std::shared_ptr<LocaleGroup> alloc(std::shared_ptr<JsonValue> json) {
        std::shared_ptr<LocaleGroup> result = std::make_shared<LocaleGroup>();
        return (result->init(json) ? result : nullptr);
    }

    /**
     * Returns the JsonValue representation of this locale group.
     *
     * @return a shared pointer to the JsonValue representation of this locale group.
     */
    const std::shared_ptr<JsonValue> getJson() const { return _json; }

    /**
     * Returns the localized string for the given key using the current language.
     *
     * This method fetches the language of this locale group and retrieves
     * the value associated with the key from that group's JSON.
     *
     * @param key  The key for the localized string to retrieve.
     *
     * @return the localized string associated with the key.
     */
    std::string getLocalizedString(const std::string& key) const {
        return _json->get(getLangCode())->getString(key);
    }

    /**
     * Returns the localized string for the given key in the specified language.
     *
     * This method fetches the value associated with the key from the JSON group
     * for the given language code. This is NOT the preferred way of accessing
     * localized strings, strongly consider using the version of this method that
     * does not specify a language code.
     *
     * @param key       The key for the localized string to retrieve.
     * @param langCode  The language code for the localization group to use.
     *
     * @return the localized string associated with the key in the specified
     * language.
     */
    std::string getLocalizedString(const std::string& key, const std::string& langCode) const {
        return _json->get(langCode)->getString(key);
    }

    /**
     * Returns the current language code used by this LocaleGroup.
     *
     * @return the current language code used.
     */
    std::string getLangCode() const { return _json->get("meta")->getString("current"); }

    /**
     * Sets the language code used by this LocaleGroup.
     *
     * @param langCode  The new language code to use.
     */
    void setLangCode(const std::string& langCode) const {
        _json->get("meta")->get("current")->set(langCode);
    }

    /**
     * Returns the raw JSON object listing supported language codes and names.
     *
     * This method accesses the "meta.supported" field, which is a JSON object
     * mapping language codes (e.g., "en", "es") to their human-readable
     * language names (e.g., "English", "Español"). The structure is not
     * parsed or converted; use this method if you want direct access to the
     * JSON object for iteration or inspection.
     *
     * @return the JSON object containing supported language codes and names.
     */
    const std::shared_ptr<JsonValue> getSupportedLangs() const {
        return _json->get("meta")->get("supported");
    }
};

}  // namespace cugl

#endif /* __CU_LOC_GROUP_VALUE_H__ */
