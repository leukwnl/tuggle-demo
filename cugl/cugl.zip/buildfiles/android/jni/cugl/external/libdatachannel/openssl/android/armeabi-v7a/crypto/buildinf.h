/* auto-generated for crypto/cversion.c */
#define CFLAGS "compiler: Clang -fPIC"
#define PLATFORM "platform: Android"
#define DATE "built on: 2023-01-16 23:34:26 UTC"
static const char *compiler_flags = CFLAGS;

