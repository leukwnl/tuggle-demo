# Harfbuzz Path Directory

The src directory exists because Harfbuzz needs a small patch and we do not wish to fork that repository.